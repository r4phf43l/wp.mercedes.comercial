<?php if ( is_active_sidebar( 'block2' ) ) : ?>
<?php dynamic_sidebar( 'block2' ); ?>
<?php endif; ?>