<?php if ( is_active_sidebar( 'block3' ) ) : ?>
<?php dynamic_sidebar( 'block3' ); ?>
<?php endif; ?>