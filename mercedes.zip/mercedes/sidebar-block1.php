<?php if ( is_active_sidebar( 'block1' ) ) : ?>
<?php dynamic_sidebar( 'block1' ); ?>
<?php endif; ?>